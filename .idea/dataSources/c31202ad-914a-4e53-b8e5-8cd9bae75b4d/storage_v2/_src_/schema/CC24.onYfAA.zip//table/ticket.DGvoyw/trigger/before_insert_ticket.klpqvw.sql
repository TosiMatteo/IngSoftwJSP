create definer = matteo@localhost trigger before_insert_ticket
    before insert
    on ticket
    for each row
BEGIN
SET NEW.date = CURRENT_DATE;
END;

